
package inventario.burgerhouse.singleton;

/**
 *
 * @author dct-yulieth
 */
public class StockInsuficienteException extends Exception {
    public StockInsuficienteException(String message) {
        super(message);
    }
}
