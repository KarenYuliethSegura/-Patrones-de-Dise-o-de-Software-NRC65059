
package inventario.burgerhouse.domain;
/**
 *
 * @author yulieth segura
 */
public enum Categoria {
    FRESCOS,
    CONSERVAS,
    PANADERIA,
    BEBIDAS
}
